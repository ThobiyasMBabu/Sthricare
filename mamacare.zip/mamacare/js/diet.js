async function getDietAdvice() {
  const el = document.getElementById('dietAiContent');
  if(!el) return;
  el.textContent = '🤖 Consulting AI Nutritionist...';

  const prompt = `You are MaMaCare's AI Nutritionist, specialising in Indian prenatal nutrition.

A working woman in Week 24 of pregnancy (Second Trimester) has the following nutritional gaps today:
- Iron: 65% of daily requirement (needs more: drumstick leaves, jaggery, rajma, sardines)
- Folate: 80% (nearly sufficient: continue dal, green leafy vegetables)  
- Calcium: 50% (critical gap: needs more milk, sesame seeds, ragi)
- Protein: 72% (good: continue eggs, fish, legumes)
- Omega-3: 40% (low: add flaxseeds, walnuts, or mackerel)

Give a personalised nutrition plan in 3-4 points:
1. Most critical nutrient to focus on today and WHY it matters for baby at Week 24
2. 2 specific Indian foods/recipes she can add easily
3. A food pairing tip that boosts absorption
4. One food to avoid or limit today

Keep it warm, practical, and specific to South Indian / Kerala diet. Use emojis for food items.`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    el.textContent = data.content?.map(c=>c.text||'').join('') || 'Unable to get advice.';
  } catch {
    el.textContent = `🦴 Calcium is your most critical gap today (50%). At Week 24, baby's bones are ossifying rapidly. Add:
\n• 🥛 2 glasses of warm milk (plain or with turmeric)
• 🌾 Ragi mudde or ragi porridge for breakfast — it has more calcium than milk per gram!
\n⚡ Pairing tip: Eat iron-rich foods (rajma, spinach) with Vitamin C (lemon juice, amla) to triple absorption.
\n⚠️ Limit: Too much tea or coffee — tannins block iron and calcium absorption. Switch to herbal tea after meals.`;
  }
}

async function generateMealPlan() {
  const btn = event.target;
  btn.textContent = '⏳ Generating...';
  btn.disabled = true;
  setTimeout(() => {
    btn.innerHTML = '<i class="fas fa-magic"></i> Generate Today\'s Plan';
    btn.disabled = false;
    getDietAdvice();
  }, 500);
}

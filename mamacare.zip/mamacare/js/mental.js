// ===== CHARTS =====
document.addEventListener('DOMContentLoaded', () => {
  const moodCtx = document.getElementById('moodWeekChart');
  if(moodCtx) {
    new Chart(moodCtx, {
      type: 'bar',
      data: {
        labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
        datasets: [{
          label: 'Mood Score',
          data: [45, 38, 42, 35, 72, 85, 78],
          backgroundColor: [
            '#f5576c','#f5576c','#f5576c','#f5576c',
            '#43e97b','#43e97b','#4facfe'
          ],
          borderRadius: 8,
          borderSkipped: false,
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          y: { min: 0, max: 100, grid: { color: 'rgba(240,147,251,0.1)' }, ticks: { font: { family: 'Nunito', size: 11 } } },
          x: { grid: { display: false }, ticks: { font: { family: 'Nunito', size: 11 } } }
        }
      }
    });
  }
});

// ===== GAD ANALYSIS =====
async function analyzeGAD() {
  const scores = [];
  for(let i = 0; i < 7; i++) {
    const sel = document.querySelector(`input[name="gad${i}"]:checked`);
    scores.push(sel ? parseInt(sel.value) : 0);
  }
  const total = scores.reduce((a,b)=>a+b,0);

  let severity = '';
  if(total <= 4) severity = 'Minimal anxiety';
  else if(total <= 9) severity = 'Mild anxiety';
  else if(total <= 14) severity = 'Moderate anxiety';
  else severity = 'Severe anxiety';

  const resultEl = document.getElementById('gadResult');
  const contentEl = document.getElementById('gadContent');
  if(!resultEl || !contentEl) return;

  resultEl.style.display = 'block';
  contentEl.textContent = '🤖 Analysing your responses...';

  const prompt = `You are MaMaCare's compassionate AI mental health companion for pregnant working women.

A woman in Week 24 of pregnancy completed a GAD-7 anxiety assessment:
- Total score: ${total}/21
- Severity level: ${severity}
- Individual question scores: ${scores.join(', ')}

Provide a warm, supportive 3-4 paragraph response that:
1. Acknowledges her score compassionately (don't be alarming, but be honest)
2. Explains how prenatal anxiety affects mom and baby (briefly, not scary)
3. Gives 3 specific, practical coping strategies she can use right now as a working mom
4. Encourages her to speak to her doctor if score is moderate-severe

Important: Be warm, non-judgmental, and empowering. This is not a diagnosis. Remind her she is not alone.`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    contentEl.textContent = data.content?.map(c=>c.text||'').join('') || getDefaultGADResponse(total, severity);
  } catch {
    contentEl.textContent = getDefaultGADResponse(total, severity);
  }
}

function getDefaultGADResponse(score, severity) {
  return `Your score of ${score} indicates ${severity}.\n\nFirst, take a deep breath — you are incredibly brave for checking in on your mental health. Many pregnant working women experience anxiety, especially in the second trimester when the reality of parenthood becomes more real.\n\nHere are 3 things you can do right now:\n1. 🌬️ Try the 4-7-8 breathing below — even 3 cycles can calm your nervous system\n2. 📝 Write down one worry and one thing you're grateful for — shifts perspective instantly\n3. 🤝 Talk to one trusted person today — your partner, friend, or doctor\n\nPlease share this score with your OB or midwife at your next appointment. You deserve support, mama. 💗`;
}

// ===== EXERCISES =====
function startBreathing() {
  document.getElementById('breathingModal').style.display = 'flex';
}

function closeModal() {
  document.getElementById('breathingModal').style.display = 'none';
  clearInterval(breathInterval);
  breathing = false;
  document.getElementById('breathBtn').textContent = 'Start';
  document.getElementById('breathText').textContent = 'Ready?';
  document.getElementById('breathCount').textContent = '';
  document.getElementById('breathInstruction').textContent = 'Press Start to begin';
}

let breathing = false;
let breathInterval = null;

function startBreathCycle() {
  if(breathing) { closeModal(); return; }
  breathing = true;
  document.getElementById('breathBtn').textContent = 'Stop';

  const phases = [
    { text: 'Inhale', instruction: 'Breathe in slowly through your nose...', count: 4, color: '#4facfe', size: '200px' },
    { text: 'Hold', instruction: 'Hold your breath gently...', count: 7, color: '#a18cd1', size: '200px' },
    { text: 'Exhale', instruction: 'Breathe out slowly through your mouth...', count: 8, color: '#43e97b', size: '160px' },
  ];

  let phaseIdx = 0;
  let counter = phases[0].count;

  function tick() {
    const phase = phases[phaseIdx];
    const circle = document.getElementById('breathCircle');
    document.getElementById('breathText').textContent = phase.text;
    document.getElementById('breathCount').textContent = counter;
    document.getElementById('breathInstruction').textContent = phase.instruction;
    if(circle) {
      circle.style.width = phase.size;
      circle.style.height = phase.size;
      circle.style.borderColor = phase.color;
      circle.style.boxShadow = `0 0 30px ${phase.color}44`;
    }
    counter--;
    if(counter < 0) {
      phaseIdx = (phaseIdx + 1) % phases.length;
      counter = phases[phaseIdx].count;
    }
  }

  tick();
  breathInterval = setInterval(tick, 1000);
}

function startBodyScan() { alert('Body Scan Meditation: Find a comfortable position, close your eyes, and begin scanning from the top of your head slowly down to your toes, releasing any tension you find. 🧘‍♀️'); }
function startAffirmations() {
  const affirmations = [
    'I am strong, capable, and ready to be a wonderful mother.',
    'My body knows exactly what to do to nourish and protect my baby.',
    'I trust the process of pregnancy and birth.',
    'I am surrounded by love and support.',
    'Each day, my baby and I grow stronger together.'
  ];
  alert('Today\'s Affirmations:\n\n' + affirmations.map((a,i) => `${i+1}. ${a}`).join('\n\n') + '\n\nRepeat each one 3 times, hand on heart. 💗');
}

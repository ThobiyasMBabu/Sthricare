const weekData = {
  4:  { emoji:'🫐', size:'Blueberry', length:'~0.4cm', weight:'<1g', eyes:'Forming', milestone:'Neural tube forming — folate is critical!', trimester:1 },
  8:  { emoji:'🍓', size:'Strawberry', length:'~1.6cm', weight:'~1g', eyes:'Forming', milestone:'Heart beating! All major organs beginning to form.', trimester:1 },
  12: { emoji:'🍋', size:'Lime', length:'~6cm', weight:'~14g', eyes:'Closed', milestone:'First trimester ends! Risk of miscarriage drops significantly.', trimester:1 },
  16: { emoji:'🥑', size:'Avocado', length:'~12cm', weight:'~100g', eyes:'Sensitive to light', milestone:'Baby can make facial expressions and suck thumb!', trimester:2 },
  20: { emoji:'🍌', size:'Banana', length:'~25cm', weight:'~300g', eyes:'Developing', milestone:'Halfway there! Baby can hear your voice and heartbeat.', trimester:2 },
  24: { emoji:'🌽', size:'Ear of corn', length:'~30cm', weight:'~600g', eyes:'Forming retina', milestone:'Baby can hear and respond to sounds outside the womb!', trimester:2 },
  28: { emoji:'🥦', size:'Broccoli head', length:'~37cm', weight:'~1kg', eyes:'Can open & close', milestone:'Enters third trimester! Baby has 90% survival rate if born now.', trimester:3 },
  32: { emoji:'🥥', size:'Coconut', length:'~43cm', weight:'~1.7kg', eyes:'Blinking', milestone:'Baby practising breathing movements and gaining fat rapidly.', trimester:3 },
  36: { emoji:'🍈', size:'Honeydew melon', length:'~47cm', weight:'~2.6kg', eyes:'Fully developed', milestone:'Baby is considered late preterm — nearly ready!', trimester:3 },
  40: { emoji:'🎃', size:'Small pumpkin', length:'~51cm', weight:'~3.4kg', eyes:'Alert', milestone:'Full term! Baby is ready to meet you. 💗', trimester:3 }
};

function getWeekData(week) {
  const keys = Object.keys(weekData).map(Number).sort((a,b)=>a-b);
  let best = keys[0];
  for(const k of keys) { if(k <= week) best = k; }
  return weekData[best];
}

function getTrimesterLabel(t) {
  return ['', 'First Trimester', 'Second Trimester', 'Third Trimester'][t];
}

function updateWeek(week) {
  week = parseInt(week);
  const data = getWeekData(week);
  document.getElementById('weekNum').textContent = 'Week ' + week;
  document.getElementById('trimesterLabel').textContent = getTrimesterLabel(data.trimester);
  document.getElementById('babyEmoji').textContent = data.emoji;
  document.getElementById('babySizeCompare').textContent = 'Size of a ' + data.size;
  document.getElementById('babyLength').textContent = data.length;
  document.getElementById('babyWeight').textContent = data.weight;
  document.getElementById('babyEyes').textContent = data.eyes;
  document.getElementById('milestoneText').textContent = data.milestone;
  buildTimeline(week);
}

function buildTimeline(currentWeek) {
  const tl = document.getElementById('timeline');
  if(!tl) return;
  tl.innerHTML = '';
  for(let w = 4; w <= 40; w++) {
    const div = document.createElement('div');
    const data = getWeekData(w);
    const t = data.trimester;
    const cls = ['tl-week', `tl-t${t}`, w === currentWeek ? 'tl-current' : ''].join(' ');
    div.className = cls;
    const heightPct = 30 + (w / 40) * 70;
    div.style.height = heightPct + '%';
    div.title = `Week ${w}`;
    div.onclick = () => {
      document.getElementById('weekSlider').value = w;
      updateWeek(w);
    };
    tl.appendChild(div);
  }
}

async function getFetusTip() {
  const week = parseInt(document.getElementById('weekSlider')?.value || 24);
  const data = getWeekData(week);
  const tipEl = document.getElementById('fetusTip');
  if(!tipEl) return;
  tipEl.textContent = '🤖 Generating personalised tip...';

  const prompt = `You are MaMaCare AI, a warm and knowledgeable maternal health assistant. 

A working pregnant woman is at Week ${week} of pregnancy. Her baby is the size of a ${data.size} (${data.length}, ${data.weight}).

Current milestone: "${data.milestone}"

Give ONE specific, actionable tip (2-3 sentences max) for this week that:
- Connects to something developing in the baby right now
- Is practical for a busy working woman
- Feels warm and encouraging

Be conversational, not clinical. End with a brief encouraging note.`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data2 = await res.json();
    tipEl.textContent = data2.content?.map(c=>c.text||'').join('') || 'Unable to load tip.';
  } catch {
    tipEl.textContent = `At Week ${week}, your baby is rapidly developing. Focus on iron-rich foods like spinach and lentils paired with Vitamin C to boost absorption. Your choices right now directly shape your baby's brain and organ development. You're doing amazingly! 🌸`;
  }
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  updateWeek(24);
  getFetusTip();
});

// ===== DATE =====
const d = new Date();
const opts = { weekday:'long', year:'numeric', month:'long', day:'numeric' };
const el = document.getElementById('greetingDate');
if(el) el.innerHTML = `<div class="date-big">${d.getDate()}</div><div class="date-small">${d.toLocaleDateString('en-IN',{month:'short',year:'numeric'})}</div>`;

// ===== MOOD =====
let selectedMood = null;
function selectMood(btn) {
  document.querySelectorAll('.mood-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  selectedMood = btn.dataset;
}

// ===== SLEEP =====
function updateSleepFeedback(val) {
  const fb = document.getElementById('sleepFeedback');
  if(!fb) return;
  if(val < 6) fb.textContent = '⚠️ Too little sleep. Aim for 7-9 hours.';
  else if(val > 9) fb.textContent = '😴 Slightly too much. 7-9 hours is ideal.';
  else fb.textContent = '✅ Good sleep for pregnancy';
}

// ===== FOOD SCORE =====
function updateFoodScore() {
  const boxes = ['fc1','fc2','fc3','fc4','fc5','fc6'];
  const checked = boxes.filter(id => document.getElementById(id)?.checked).length;
  const pct = (checked / 6) * 100;
  const fill = document.getElementById('foodFill');
  const fb = document.getElementById('foodFeedback');
  if(fill) fill.style.width = pct + '%';
  if(fb) {
    if(checked === 0) fb.textContent = 'Select what you\'ve eaten';
    else if(checked < 3) fb.textContent = '⚠️ Need more food groups today';
    else if(checked < 5) fb.textContent = '🟡 Getting there! Try to include more groups';
    else fb.textContent = '✅ Excellent nutrition balance!';
  }
}

// ===== CHARTS =====
window.addEventListener('DOMContentLoaded', () => {
  // Mood chart
  const moodCtx = document.getElementById('moodChart');
  if(moodCtx) {
    new Chart(moodCtx, {
      type: 'line',
      data: {
        labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
        datasets: [{
          label: 'Mood Score',
          data: [65, 50, 45, 70, 80, 90, 75],
          borderColor: '#f5576c',
          backgroundColor: 'rgba(240,147,251,0.1)',
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#f5576c',
          pointRadius: 5,
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          y: { min: 0, max: 100, grid: { color: 'rgba(240,147,251,0.1)' },
            ticks: { font: { family: 'Nunito', size: 11 } } },
          x: { grid: { display: false }, ticks: { font: { family: 'Nunito', size: 11 } } }
        }
      }
    });
  }

  // Nutrition donut chart
  const nutCtx = document.getElementById('nutritionChart');
  if(nutCtx) {
    new Chart(nutCtx, {
      type: 'doughnut',
      data: {
        labels: ['Iron','Folate','Calcium','Protein','Omega-3'],
        datasets: [{
          data: [65, 80, 50, 72, 40],
          backgroundColor: ['#f5576c','#4facfe','#43e97b','#ffd200','#a18cd1'],
          borderWidth: 0,
        }]
      },
      options: {
        cutout: '65%',
        plugins: {
          legend: { position: 'right', labels: { font: { family: 'Nunito', size: 11 }, padding: 10 } }
        }
      }
    });
  }
});

// ===== AI CHECK-IN =====
async function submitCheckin() {
  const sleepHours = document.getElementById('sleepRange')?.value || 7;
  const moodLabel = selectedMood?.label || 'Not logged';
  const foodItems = ['Grains','Vegetables','Fruits','Protein','Dairy','Water']
    .filter((_, i) => document.getElementById('fc'+(i+1))?.checked);

  const responseBox = document.getElementById('aiResponse');
  const contentBox = document.getElementById('aiContent');
  if(!responseBox || !contentBox) return;

  responseBox.style.display = 'block';
  contentBox.textContent = '🤖 Analysing your health data...';

  const prompt = `You are MaMaCare AI, a compassionate maternal health assistant for working pregnant women. 

A user in Week 24 of pregnancy has submitted her daily health check-in:
- Mood: ${moodLabel}
- Sleep last night: ${sleepHours} hours
- Food groups consumed today: ${foodItems.length > 0 ? foodItems.join(', ') : 'None logged yet'}

Give a warm, encouraging, and medically-informed response (3-4 sentences) that:
1. Acknowledges her check-in positively
2. Notes any concerns (e.g., low sleep, mood, missing nutrients)
3. Gives 1-2 actionable tips for the day
4. Mentions how today's choices affect baby at Week 24

Be warm, brief, and supportive. Use emojis sparingly. Sign off as "MaMaCare AI 🌸"`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    const text = data.content?.map(c => c.text || '').join('') || 'Unable to get response.';
    contentBox.textContent = text;
  } catch(err) {
    contentBox.textContent = `✅ Check-in recorded!\n\nBased on your ${sleepHours} hours of sleep and ${moodLabel} mood, you're doing great! Remember to drink 2L of water and take your iron supplement today. Your baby at Week 24 benefits most from iron-rich foods and quality rest. Keep it up, mama! 🌸\n\n— MaMaCare AI`;
  }
}

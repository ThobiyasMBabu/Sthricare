// ===== SESSION TIMER =====
let sessionSeconds = 9252; // 2h 34m 12s
let sittingSeconds = 9252;
let breakSeconds = 26 * 60;
let timerRunning = true;
let breakTimerSeconds = 0;
let breakTimerRunning = false;
let breakTimerInterval = null;

function formatTime(s) {
  const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
  return [h,m,sec].map(v=>String(v).padStart(2,'0')).join(':');
}

function formatShort(s) {
  const h = Math.floor(s/3600), m = Math.floor((s%3600)/60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

setInterval(() => {
  if(!timerRunning) return;
  sessionSeconds++;
  sittingSeconds++;
  if(breakSeconds > 0) breakSeconds--;

  const st = document.getElementById('sessionTime');
  if(st) st.textContent = formatTime(sessionSeconds);

  const sit = document.getElementById('sittingTime');
  if(sit) sit.textContent = formatShort(sittingSeconds);

  const bc = document.getElementById('breakCountdown');
  if(bc) bc.textContent = formatShort(breakSeconds);

  const fill = document.getElementById('breakFill');
  if(fill) {
    const pct = 100 - (breakSeconds / (45*60)) * 100;
    fill.style.width = Math.min(100, Math.max(0, pct)) + '%';
  }

  // Alert at 45min sitting
  const warn = document.getElementById('sittingWarn');
  if(warn) {
    if(sittingSeconds > 45*60) warn.style.color = '#c62828';
    else warn.style.color = '#f57c00';
  }
}, 1000);

function startSession() {
  timerRunning = true;
  sessionSeconds = 0; sittingSeconds = 0; breakSeconds = 45*60;
  alert('Work session started! MaMaCare will remind you to take breaks every 45 minutes. 💪');
}

// ===== CHARTS =====
document.addEventListener('DOMContentLoaded', () => {
  const whCtx = document.getElementById('workHoursChart');
  if(whCtx) {
    new Chart(whCtx, {
      type: 'doughnut',
      data: {
        labels: ['Sitting', 'Standing/Walking', 'Break Time'],
        datasets: [{
          data: [74, 15, 11],
          backgroundColor: ['#f5576c', '#43e97b', '#4facfe'],
          borderWidth: 0
        }]
      },
      options: {
        cutout: '60%',
        plugins: { legend: { position: 'bottom', labels: { font: { family: 'Nunito', size: 11 }, padding: 12 } } }
      }
    });
  }

  const wpCtx = document.getElementById('weekPatternChart');
  if(wpCtx) {
    new Chart(wpCtx, {
      type: 'bar',
      data: {
        labels: ['Mon','Tue','Wed','Thu','Fri'],
        datasets: [
          { label: 'Work Hours', data: [9, 10, 8.5, 10, 7], backgroundColor: 'rgba(240,147,251,0.7)', borderRadius: 6, borderSkipped: false },
          { label: 'Breaks', data: [3, 2, 4, 1, 5], backgroundColor: 'rgba(67,233,123,0.7)', borderRadius: 6, borderSkipped: false }
        ]
      },
      options: {
        plugins: { legend: { position: 'bottom', labels: { font: { family: 'Nunito', size: 11 } } } },
        scales: {
          y: { grid: { color: 'rgba(240,147,251,0.1)' }, ticks: { font: { family: 'Nunito', size: 11 } } },
          x: { grid: { display: false }, ticks: { font: { family: 'Nunito', size: 11 } } }
        }
      }
    });
  }
});

// ===== AI WORK ADVICE =====
async function getWorkAdvice() {
  const input = document.getElementById('workInput')?.value?.trim();
  if(!input) { alert('Please describe your work situation first.'); return; }

  const respEl = document.getElementById('workAiResponse');
  const contentEl = document.getElementById('workAiContent');
  if(!respEl || !contentEl) return;

  respEl.style.display = 'block';
  contentEl.textContent = '🤖 Analysing your work situation...';

  const prompt = `You are MaMaCare's AI work-life balance coach specialising in pregnancy and occupational health.

A working pregnant woman at Week 24 describes her workday:
"${input}"

Provide compassionate, practical advice in 3-4 points:
1. The biggest risk in what she described (for her and baby) — be direct but gentle
2. 2-3 specific changes she can make tomorrow to reduce physical and mental strain
3. What to communicate to her manager or HR (specific language she can use)
4. One immediate thing she should do right now

Keep it warm, empowering, and actionable. Remember she is a working professional managing pregnancy — treat her with respect.`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    contentEl.textContent = data.content?.map(c=>c.text||'').join('') || getDefaultWorkAdvice();
  } catch {
    contentEl.textContent = getDefaultWorkAdvice();
  }
}

function getDefaultWorkAdvice() {
  return `Based on what you've shared, the biggest concern is extended sitting and stress accumulation, which can reduce blood flow to your baby and elevate cortisol levels.\n\nFor tomorrow:\n1. Set a 45-minute phone alarm — non-negotiable standing time\n2. Block 30 minutes for lunch away from your desk\n3. Do 3 shoulder/neck rolls every hour\n\nFor your manager, you can say: "I'd like to discuss pregnancy accommodations — specifically, flexibility to take short movement breaks every hour as recommended by my doctor."\n\nRight now: Drink a full glass of water and do 10 calf raises at your desk. 💪🌸`;
}

// ===== BREAK TIMER =====
function startBreakTimer(minutes) {
  if(breakTimerRunning) { clearInterval(breakTimerInterval); breakTimerRunning = false; }
  breakTimerSeconds = minutes * 60;
  breakTimerRunning = true;
  document.getElementById('timerLabel').textContent = `${minutes}-Minute Break Timer`;

  breakTimerInterval = setInterval(() => {
    breakTimerSeconds--;
    const m = Math.floor(breakTimerSeconds / 60);
    const s = breakTimerSeconds % 60;
    const bigTimer = document.getElementById('bigTimer');
    if(bigTimer) bigTimer.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;

    if(breakTimerSeconds <= 0) {
      clearInterval(breakTimerInterval);
      breakTimerRunning = false;
      document.getElementById('bigTimer').textContent = '00:00';
      document.getElementById('timerLabel').textContent = '✅ Break complete! Great job.';
      // Browser notification if permission granted
      if(Notification.permission === 'granted') {
        new Notification('MaMaCare 🌸', { body: 'Break time is over! Hope you stretched and hydrated. Back to work, mama! 💪', icon: '' });
      }
    }
  }, 1000);

  // Request notification permission
  if(Notification.permission === 'default') Notification.requestPermission();
}
